import { Query, Args, Resolver } from '@nestjs/graphql';
import { ProductService } from '../product/product.service';
import { AccountService } from '../account/account.service';
import { Product, Account, Binary } from 'src/graphql';

@Resolver()
export class NodeResolver {
  constructor(
    private productService: ProductService,
    private accountService: AccountService,
  ) {}

  @Query('node')
  async node(@Args('id') id: Binary): Promise<Product | Account> {
    // Type cast the entity returned from productService.retrieve to Product
    let entity: Product | Account = (await this.productService.retrieve(
      id,
    )) as Product;

    // If not found, try to fetch an Account with the given ID
    if (!entity) {
      entity = (await this.accountService.retrieveById(id)) as Account;
    }

    // If still not found, throw an error
    if (!entity) {
      throw new Error('Entity not found');
    }

    return entity;
  }
}
