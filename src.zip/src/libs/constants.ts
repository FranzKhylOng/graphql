export const jwtConstants = {
  secret: 'secretcodeshhh',
};
